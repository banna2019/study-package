#!/bin/bash


SQL_DIR='/data/sql'
BINLOG_DIR='/data/backup'
SLEEP_SECONDS=3600
SQL_LOG='/data/logs/to-sql.logs'

if [ -d ${BINLOG_DIR} ];then
   cd ${BINLOG_DIR}
else
   echo "${BINLOG_DIR} directory is does not exist!"
   exit 1
fi


while :
do
  if [ `ls -A "${BINLOG_DIR}" |wc -l` -lt 10 ];then
      echo "${SLEEP_SECONDS}秒后再次连接并继续备份" | tee -a ${SQL_LOG}
      sleep ${SLEEP_SECONDS}
  else
     for i in `ls *`:
         do
             /data/scripts/binlog2sql/binlog2sql/binlog2sql.py -h banna-mysql.ccrj65bnfxba.ap-southeast-1.rds.amazonaws.com  -u root -p 27jq7bhfO81B6qqNZfx6jK0R --start-file="$i" --stop-file="$i" >>${SQL_DIR}/${i}.sql && rm ${i} -rf 2>&1 >>/data/logs/to-sql.logs
         done
  fi
done

