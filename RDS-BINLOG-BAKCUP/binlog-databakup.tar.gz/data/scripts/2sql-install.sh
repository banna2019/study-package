#!/bin/bash

source /etc/profile

PYPTAH='/bin/python'
SQLFILE='/data/scripts/binlog2sql/binlog2sql/binlog2sql.py'

yum install gcc gcc-c++ epel-release -y
yum install python-pip -y


cd /data/scripts && \
/usr/bin/git clone https://github.com/danfengcao/binlog2sql.git && \
cd /data/scripts/binlog2sql/ && \
pip install -r requirements.txt && \
echo "alias binlog2sql='${PYPTAH} ${SQLFILE}'" >> /root/.bashrc
source /root/.bashrc
