#!/bin/bash



BACKUP_SYN=/bin/aws
LOCAL_SQL_DIR=/data/sql
BACKUP_LOG=/data/logs/sync.log
REMOTE_DIR='s3://binlogbak/binlog01/'

#time to wait before reconnecting after failure
SLEEP_SECONDS=10
DE=`date +"%Y-%m-%d %H:%M:%S"`

##create local_backup_dir if necessary
if [ ! -d ${LOCAL_SQL_DIR} ];then
    mkdir -pv ${LOCAL_SQL_DIR} && mkdir -pv /data/logs
else
	cd ${LOCAL_SQL_DIR}
fi

echo "${DE}"  >>/data/logs/sync.log
${BACKUP_SYN} s3 sync . ${REMOTE_DIR} 2>&1 >>/data/logs/sync.log
