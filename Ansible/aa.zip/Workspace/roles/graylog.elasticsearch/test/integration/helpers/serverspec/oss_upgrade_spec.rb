require 'spec_helper'

shared_examples 'oss_upgrade::init' do |vars|
end
