require 'spec_helper'
require 'json'
vars = JSON.parse(File.read('/tmp/vars.json'))

shared_examples 'issue_test::init' do |vars|

  #Add custom tests here for the issue-test.yml test

end

